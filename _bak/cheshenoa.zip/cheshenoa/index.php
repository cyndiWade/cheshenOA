
<?php 
	//开启调试模式
	define('APP_DEBUG',true);
	//项目名称
	define('APP_NAME','App');
	//项目路径
	define('APP_PATH','App/');

	//引入框架核心文件
	require'../ThinkPHP/ThinkPHP3.1.3/ThinkPHP.php';

?>