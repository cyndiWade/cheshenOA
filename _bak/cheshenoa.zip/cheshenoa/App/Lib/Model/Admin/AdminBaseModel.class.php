<?php 

/**
 * 后台管理模型类
 */

class AdminBaseModel extends AppBaseModel {
	
	
}
?>