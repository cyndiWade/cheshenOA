<?php 

/**
 * API-基础模型
 */

class ApiBaseModel extends AppBaseModel {
	
	
}
?>