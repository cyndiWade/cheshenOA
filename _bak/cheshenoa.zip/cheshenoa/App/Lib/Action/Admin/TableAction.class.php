<?php
/**
 * 登陆控制器
 * @author Administrator
 *
 */
class TableAction extends AdminBaseAction {
    
	
	//需要验证的模块
	protected $aVerify = array(
		
	);
	
	
	public function index() {
	
	}
    
	
	public function aaa() {

	}
	
}