<?php
/**
 * 人事管理下的---员工管理
 */
class StaffAction extends AdminBaseAction {
	
	private $MODULE = '人事管理';
	
	/**
	 * 构造方法
	 */
	public function __construct() {
		parent::__construct();
		$this->assign('MODULE_NAME',$this->MODULE);
	}
	
	

	/* 员工列表 */
	public function index () {
		
		$Staff = D('Staff');	//员工模型表
		$staff_list = $Staff->seek_data_list();
	
		
		$this->assign('staff_list',$staff_list);
		$this->assign('ACTION_NAME','员工管理');
		$this->display();
	}
     
	public function staff_edit() {
		
		$this->assign('ACTION_NAME','编辑员工信息');
		$this->display();
	}
	
    
}