<?php
/**
 * 后台主页
 *
 */
class IndexAction extends AdminBaseAction {
    
	

	//获取首页信息
	public function index(){

		
		$this->display();
	
    }
    /**
     * 
     * 
    		<include file="Public:header" />
    	
    	<!-- 导航文件 -->
			<include file="Public:menu" />
     */
    

	
    
}