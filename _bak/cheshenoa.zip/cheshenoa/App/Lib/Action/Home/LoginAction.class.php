<?php
/**
 * 前台登陆控制器
 */
class LoginAction extends HomeBaseAction {
    
	
    
}