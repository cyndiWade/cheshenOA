<?php 
/**
 * 中文---公共语言包
 */
return array(
	'demo1'=>'欢迎使用ThinkPHP1',
);


?>